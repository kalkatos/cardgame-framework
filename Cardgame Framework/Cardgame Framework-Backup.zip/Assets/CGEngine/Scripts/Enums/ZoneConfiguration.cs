﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CardGameFramework
{
	public enum ZoneConfiguration
	{
		Undefined,
		Stack,
		SideBySide,
		Grid
	}
}