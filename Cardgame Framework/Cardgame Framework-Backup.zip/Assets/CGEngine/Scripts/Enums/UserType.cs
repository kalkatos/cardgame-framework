﻿
namespace CardGameFramework
{
	public enum UserType
	{
		Undefined,
		Local,
		Network,
		CPU,
	}
}