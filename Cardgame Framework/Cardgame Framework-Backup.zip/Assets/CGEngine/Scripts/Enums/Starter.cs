﻿
namespace CardGameFramework
{
	public enum Starter
	{
		Random,
		FirstInList,
		SpecificRole,
		SpecificTeam
	}
}