﻿public enum ComparisonOperator
{
	Equal,
	Unequal,
	LessThan,
	LessThanOrEqualTo,
	GreaterThan,
	GreaterThanOrEqualTo
}