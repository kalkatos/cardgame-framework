﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CardGameFramework
{
    public class CardgameObject : MonoBehaviour
    {
        internal new string name;
        internal string id;
    }
}