﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CardGameFramework
{
	public enum ZoneConfiguration
	{
		Stack,
		SideBySide,
		Grid,
		SpecificPositions,
		Undefined
	}
}